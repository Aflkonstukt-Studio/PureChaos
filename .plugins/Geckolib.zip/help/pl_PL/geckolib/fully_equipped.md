Jeśli ta opcja jest zaznaczona, animacje zbroi będą odtwarzane tylko wtedy, kiedy gracz nośi pełny zestaw zbroi.
