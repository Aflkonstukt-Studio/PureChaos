This will be the name used when searching for a model group to disable and replace with a player arm.
That arm will then have the animations that the model group has.
If the model group specified does not exist, the arm will not render.