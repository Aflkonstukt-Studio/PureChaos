While the returned value is true, the entity's bounding box is solid. 
This feature is used by boats, for example.